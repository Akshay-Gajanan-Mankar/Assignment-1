function myFunction(){

    let x = document.getElementById("menu__item--click");

    if(x.style.display == "block"){
        x.style.display = "none";
    }else{
        x.style.display = "block";
    }
 }